<?php

use App\Http\Controllers\API\CategoryController;
use App\Http\Controllers\API\ContactController;
use App\Http\Controllers\API\NewsLetterController;
use App\Http\Controllers\API\OrderController;
use App\Http\Controllers\API\ProductController;
use App\Http\Controllers\API\ReviewController;
use App\Http\Controllers\API\AuthController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/



//auth urls
Route::controller(AuthController::class)->group(function () {
    Route::post('login', 'login');
    Route::post('register', 'register');
    Route::group(
        ['middleware' => 'auth:api'],
        function () {
            Route::post('logout', 'logout');
            Route::post('login/refresh', 'refresh');
            Route::get('profile/info', 'profileInfo');
        }
    );
});

Route::controller(ProductController::class)->group(function () {
    Route::get('products', 'index');
    Route::get('collections', 'collections');
    Route::get('products/best-selling', 'bestSelling');
    Route::get('products/{id}', 'show');
    Route::get('product/random', 'showRandom');
    Route::get('product/{curent_product_id}/releted-products', 'reletedProducts');
});

Route::controller(CategoryController::class)->group(function () {
    Route::get('categories', 'index');
    Route::get('categories/{id}', 'show');
    Route::get('categories/{id}/products', 'products');
});

Route::controller(ReviewController::class)->group(function () {
    Route::get('home/reviews', 'homeReviews');
    Route::post('reviews', 'store');
    //get reviews for singlr product item
    Route::get('products/{product_is}/reviews', 'productReviews');
});
Route::controller( NewsLetterController::class)->group(function () {
    Route::post('newsletter/join', 'store');
});
Route::controller( ContactController::class)->group(function () {
    Route::post('contact', 'contact');
});

Route::controller( OrderController::class)->group(function () {
    Route::post('orders', 'store');
});