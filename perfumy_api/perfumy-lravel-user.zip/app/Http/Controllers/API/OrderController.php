<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Resources\ResponseResource;
use App\Models\Client;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class OrderController extends Controller
{

    public function store(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                "name" => "required|string",
                "address" => "required|string",
                "city" => "required|string",
                "email" => "required|email",
                "phone" => "required",
            ]
        );

        if ($validator->fails()) {
            return ResponseResource::error('invalid data sent', 409, $validator->errors());
        }

        // generatee a random id for order
        $order_id = time();

        // Your string representation of JSON array
        $cart = $request->cart;

        // Decode the JSON string into a PHP array
        $arrayCart = json_decode($cart, true);

        // Print the resulting PHP array
        // dd($cart);
        // dd($arrayCart[0]['id']);

        $auth = Auth::user();
        $user_id = null;
        if ($auth) {
            $user_id = $auth->id;
        }
        $client = Client::create([
            "name" => $request->name,
            "phone" => $request->phone,
            "city" => $request->city,
            "email" => $request->email,
            "user_id" => $user_id,
            "address" => $request->address
        ]);



        foreach ($arrayCart as $item) {

            $order = Order::create([
                "quantity" => $item["quantity"],
                "price" => $item["price"],
                "order_id" => $order_id,
                "book_id" => $item["id"],
                "shipped" => false,
                "client_id" => $client->id,
                "confirmed" => false
            ]);
        }

        return ResponseResource::success("order created successfully", );

    }
}