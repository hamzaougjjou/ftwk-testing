<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Visitor;
use Illuminate\Http\Request;
use Stevebauman\Location\Facades\Location;

class TrackingController extends Controller
{
    //

    public function trackVisit(Request $request)
{
    $ipAddress = $request->ip();

    // $ip = '162.159.24.227'; /* Static IP address */
    $currentUserInfo = Location::get($ipAddress);

    $visitorData = [
        'ip_address' => $ipAddress,
        'user_agent' => $request->user_agent,
        'visited_url' => $request->visited_url,
        'country' => "country",
        'city' => "city",
    ];

    // Store visitor data
    Visitor::create($visitorData);

    return response()->json([
    'message' => 'Visit tracked successfully',
    'ipAddress' => $ipAddress,
    'currentUserInfo' => $currentUserInfo

]);
}
}
