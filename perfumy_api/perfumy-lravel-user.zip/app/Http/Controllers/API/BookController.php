<?php

namespace App\Http\Controllers\API;

use App\Models\Author;
use App\Models\Book;
use App\Models\Review;
use App\Models\SubImage;
use App\Traits\FileTrait;
use App\Http\Controllers\Controller;

class BookController extends Controller
{
    use FileTrait;
    public function newBooks($limit)
    {
        $books = Book::latest()->limit($limit)->get();

        foreach ($books as $book) {
            $book->image = $this->getFilePath($book->image_id);
        }

        if (!$books) {
            return response()->json([
                'success' => false,
                'error' => "something went wrong"
            ]);
        }

        return response()->json([
            'success' => true,
            'message' => "books retrieved successfully",
            "books" => $books
        ]);
    }

    public function bestSelling($limit)
    {
        $books = Book::limit($limit)->get();
        foreach ($books as $book) {
            $book->image = $this->getFilePath($book->image_id);
            $book->author = Author::find($book->author_id);
        }

        if (!$books) {
            return response()->json([
                'success' => false,
                'error' => "something went wrong"
            ]);
        }
        return response()->json([
            'success' => true,
            'message' => "books retrieved successfully",
            "books" => $books
        ]);
    }



    public function explorerBook()
    {
        $books = Book::inRandomOrder()
        ->limit( 1 )
        ->get();

        foreach ($books as $book) {
            $book->image = $this->getFilePath($book->image_id);
            $book->author = Author::find($book->author_id);
            $sub_images_db = SubImage::where("book_id", $book->id)->get();
            $sub_images = [];
            foreach ($sub_images_db as $item) {
                array_push($sub_images, $this->getFilePath($item->file_id));
            }
            $book->sub_images = $sub_images;
        }

        if (!$books) {
            return response()->json([
                'success' => false,
                'error' => "something went wrong"
            ]);
        }
        return response()->json([
            'success' => true,
            'message' => "books retrieved successfully",
            "books" => $books
        ]);
    }


    public function suggestedBooks($limit)
    {

        $books = Book::inRandomOrder()
        ->limit( $limit )
        ->get();

        foreach ($books as $book) {

            $book->image = $this->getFilePath($book->image_id);

            $reviews = Review::where("book_id", $book->id)->get();


            if ($reviews && $reviews->count() > 0) {
                $review_avg_sum = 0;
                $reviews_count = $reviews->count();

                foreach ($reviews as $review) {
                    $review_avg_sum += $review->stars;
                }
                $review_avg = $review_avg_sum / $reviews_count;
                $book->reviews = [
                    "count" => $reviews_count,
                    "stars_sum" => $review_avg_sum,
                    "rate" => $review_avg
                ];
            } else {
                $book->reviews = [
                    "count" => 0,
                    "stars_sum" => 0,
                    "rate" => 5
                ];
            }

            if ($book->author_id) {
                $author = Author::find($book->author_id);
                $book->author = $author;
            } else {
                $book->author = null;
            }
        }


        return response()->json([
            'success' => true,
            'message' => "books retrieved successfully",
            "books" => $books
        ]);
    }


    public function show($book_id)
    {

        $book = Book::findOrFail($book_id);

        $book->image = $this->getFilePath($book->image_id);


        // ===========================================================
        return response()->json([
            'success' => true,
            'message' => "book info retrieved successfully",
            "book" => $book
        ]);

    }

}

